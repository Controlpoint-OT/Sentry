import React, { useState } from 'react';
import { LogIn, PlayCircle, RocketIcon, Mail, Lock, User, Building2, X } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { DemoRequestModal } from './DemoRequestModal';
import { AnimatedLogo } from './AnimatedLogo';
import { useAuth } from '../contexts/AuthContext';

export function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, login, signup, logout } = useAuth();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    try {
      if (isLogin) {
        await login(email, password);
        navigate('/dashboard');
      } else {
        const name = formData.get('name') as string;
        const company = formData.get('company') as string;
        await signup({ email, password, name, company });
        navigate('/dashboard');
      }
      setShowLoginModal(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  return (
    <>
      <header className="fixed w-full top-0 z-50 bg-slate-900/95 backdrop-blur-sm border-b border-slate-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <AnimatedLogo />

            <nav className="flex items-center space-x-8">
              {!user && (
                <ul className="flex items-center space-x-8">
                  <li>
                    <Link 
                      to="/" 
                      className={`${location.pathname === '/' ? 'text-white' : 'text-gray-300'} hover:text-white transition-colors`}
                    >
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/product" 
                      className={`${location.pathname === '/product' ? 'text-white' : 'text-gray-300'} hover:text-white transition-colors`}
                    >
                      Product
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/threats" 
                      className={`${location.pathname === '/threats' ? 'text-white' : 'text-gray-300'} hover:text-white transition-colors`}
                    >
                      Threats
                    </Link>
                  </li>
                  <li>
                    <Link 
                      to="/pricing" 
                      className={`${location.pathname === '/pricing' ? 'text-white' : 'text-gray-300'} hover:text-white transition-colors`}
                    >
                      Pricing
                    </Link>
                  </li>
                </ul>
              )}
              <div className="flex items-center space-x-4">
                {user ? (
                  <button
                    onClick={() => {
                      logout();
                      navigate('/');
                    }}
                    className="flex items-center gap-2 px-4 py-2 text-gray-300 hover:text-white transition-colors"
                  >
                    Logout
                  </button>
                ) : (
                  <>
                    <button 
                      onClick={() => setShowLoginModal(true)}
                      className="flex items-center gap-2 px-4 py-2 text-gray-300 hover:text-white transition-colors"
                    >
                      <LogIn className="h-5 w-5" />
                      <span>Login</span>
                    </button>
                    <button 
                      onClick={() => setShowDemoModal(true)}
                      className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors"
                    >
                      <PlayCircle className="h-5 w-5" />
                      <span>Request Demo</span>
                    </button>
                    <Link 
                      to="/pricing"
                      className="flex items-center gap-2 px-4 py-2 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-colors"
                    >
                      <RocketIcon className="h-5 w-5" />
                      <span>Get Started</span>
                    </Link>
                  </>
                )}
              </div>
            </nav>
          </div>
        </div>
      </header>

      {/* Login/Signup Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-slate-800 rounded-lg p-8 w-full max-w-md relative">
            <button 
              onClick={() => setShowLoginModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-2">
                {isLogin ? 'Welcome Back!' : 'Create Account'}
              </h2>
              <p className="text-gray-400">
                {isLogin 
                  ? 'Sign in to access your dashboard.' 
                  : 'Join us to enhance the security of your OT environment.'}
              </p>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500 rounded-lg text-red-500">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <>
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-400 mb-2">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-slate-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500"
                        placeholder="John Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm font-medium text-gray-400 mb-2">
                      Company Name
                    </label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <input
                        type="text"
                        id="company"
                        name="company"
                        required
                        className="w-full pl-10 pr-4 py-3 bg-slate-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500"
                        placeholder="Company Inc."
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-slate-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500"
                    placeholder="john@company.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-400 mb-2">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="password"
                    id="password"
                    name="password"
                    required
                    className="w-full pl-10 pr-4 py-3 bg-slate-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {isLogin && (
                <div className="flex items-center justify-between">
                  <label className="flex items-center">
                    <input type="checkbox" className="rounded bg-slate-700 border-slate-600 text-cyan-500 focus:ring-cyan-500" />
                    <span className="ml-2 text-sm text-gray-400">Remember me</span>
                  </label>
                  <button type="button" className="text-sm text-cyan-500 hover:text-cyan-400">
                    Forgot password?
                  </button>
                </div>
              )}

              <button 
                type="submit"
                className="w-full py-3 bg-cyan-500 text-white rounded-lg hover:bg-cyan-600 transition-colors font-semibold"
              >
                {isLogin ? 'Sign In' : 'Create Account'}
              </button>

              <div className="text-center text-sm">
                <span className="text-gray-400">
                  {isLogin ? "Don't have an account? " : 'Already have an account? '}
                </span>
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-cyan-500 hover:text-cyan-400 font-medium"
                >
                  {isLogin ? 'Sign up' : 'Sign in'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Demo Request Modal */}
      <DemoRequestModal isOpen={showDemoModal} onClose={() => setShowDemoModal(false)} />
    </>
  );
}