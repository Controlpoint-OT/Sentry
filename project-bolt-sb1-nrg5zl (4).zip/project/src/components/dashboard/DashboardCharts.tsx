import React, { useState } from 'react';
import { 
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, Sector, Area, AreaChart, 
  LineChart, Line
} from 'recharts';
import { Shield, AlertTriangle, Activity, Zap } from 'lucide-react';

const COLORS = ['#06b6d4', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

interface ChartData {
  name: string;
  value: number;
}

const renderActiveShape = (props: any) => {
  const {
    cx, cy, innerRadius, outerRadius, startAngle, endAngle,
    fill, payload, percent, value
  } = props;

  return (
    <g>
      <text x={cx} y={cy} dy={-20} textAnchor="middle" fill="#fff" className="text-lg">
        {payload.name}
      </text>
      <text x={cx} y={cy} dy={20} textAnchor="middle" fill="#fff">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 6}
        outerRadius={outerRadius + 10}
        fill={fill}
      />
    </g>
  );
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-700 p-3 rounded-lg shadow-lg border border-slate-600">
        <p className="text-white font-semibold">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function DashboardCharts() {
  const [activeIndex, setActiveIndex] = useState(0);

  const severityData: ChartData[] = [
    { name: 'Critical', value: 43 },
    { name: 'High', value: 189 },
    { name: 'Medium', value: 276 },
    { name: 'Low', value: 124 }
  ];

  const oemData: ChartData[] = [
    { name: 'Siemens', value: 156 },
    { name: 'Schneider', value: 142 },
    { name: 'Rockwell', value: 98 },
    { name: 'ABB', value: 87 },
    { name: 'Honeywell', value: 76 }
  ];

  const monthlyData = [
    { month: 'Jan', vulnerabilities: 45, threats: 32, incidents: 12 },
    { month: 'Feb', vulnerabilities: 52, threats: 38, incidents: 15 },
    { month: 'Mar', vulnerabilities: 48, threats: 35, incidents: 10 },
    { month: 'Apr', vulnerabilities: 63, threats: 45, incidents: 18 },
    { month: 'May', vulnerabilities: 58, threats: 42, incidents: 14 },
    { month: 'Jun', vulnerabilities: 71, threats: 52, incidents: 20 }
  ];

  const attackTypeData = [
    { name: 'Remote Code Execution', value: 89 },
    { name: 'Buffer Overflow', value: 67 },
    { name: 'DoS', value: 45 },
    { name: 'Authentication Bypass', value: 34 },
    { name: 'Information Disclosure', value: 23 }
  ];

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
      {/* Severity Distribution */}
      <div className="bg-slate-800 p-6 rounded-lg hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-red-500/10 rounded-lg">
            <AlertTriangle className="h-6 w-6 text-red-500" />
          </div>
          <h3 className="text-xl font-semibold text-white">Severity Distribution</h3>
        </div>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                activeIndex={activeIndex}
                activeShape={renderActiveShape}
                data={severityData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                onMouseEnter={onPieEnter}
              >
                {severityData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* OEM Vulnerabilities */}
      <div className="bg-slate-800 p-6 rounded-lg hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-500/10 rounded-lg">
            <Shield className="h-6 w-6 text-blue-500" />
          </div>
          <h3 className="text-xl font-semibold text-white">OEM Vulnerabilities</h3>
        </div>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={oemData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip content={<CustomTooltip />} />
              <Bar
                dataKey="value"
                fill="#3b82f6"
                radius={[4, 4, 0, 0]}
                animationBegin={200}
                animationDuration={1500}
              >
                {oemData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Monthly Trend */}
      <div className="bg-slate-800 p-6 rounded-lg hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-cyan-500/10 rounded-lg">
            <Activity className="h-6 w-6 text-cyan-500" />
          </div>
          <h3 className="text-xl font-semibold text-white">Monthly Trend Analysis</h3>
        </div>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="colorVuln" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="month" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip content={<CustomTooltip />} />
              <Area
                type="monotone"
                dataKey="vulnerabilities"
                stroke="#06b6d4"
                fillOpacity={1}
                fill="url(#colorVuln)"
              />
              <Area
                type="monotone"
                dataKey="threats"
                stroke="#3b82f6"
                fillOpacity={1}
                fill="url(#colorThreats)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Attack Types */}
      <div className="bg-slate-800 p-6 rounded-lg hover:shadow-lg transition-shadow">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-yellow-500/10 rounded-lg">
            <Zap className="h-6 w-6 text-yellow-500" />
          </div>
          <h3 className="text-xl font-semibold text-white">Attack Type Distribution</h3>
        </div>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={attackTypeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" angle={-45} textAnchor="end" height={80} />
              <YAxis stroke="#9ca3af" />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#f59e0b"
                strokeWidth={2}
                dot={{ fill: '#f59e0b', r: 6 }}
                activeDot={{ r: 8, fill: '#f59e0b', stroke: '#fff' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}