import React from 'react';
import { Radio, AlertTriangle, ExternalLink } from 'lucide-react';

export function ThreatFeedsTab() {
  const feeds = [
    {
      id: 1,
      name: "ICS-CERT Advisories",
      description: "Official alerts and advisories for industrial control systems",
      source: "CISA",
      lastUpdate: "10 minutes ago",
      status: "Active",
      threatCount: 156
    },
    // Add more feeds
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Threat Feeds</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {feeds.map((feed) => (
          <div key={feed.id} className="bg-slate-800 rounded-lg p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <Radio className="h-6 w-6 text-cyan-500" />
                <div>
                  <h3 className="text-lg font-semibold text-white">{feed.name}</h3>
                  <p className="text-sm text-gray-400">{feed.source}</p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-full text-sm bg-green-500/10 text-green-500">
                {feed.status}
              </span>
            </div>
            
            <p className="text-gray-300 mb-4">{feed.description}</p>
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Last update: {feed.lastUpdate}</span>
              <span className="text-cyan-500">{feed.threatCount} threats</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}