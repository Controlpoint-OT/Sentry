import React from 'react';
import { Target, Search } from 'lucide-react';

export function IOCsTab() {
  const iocs = [
    {
      id: 1,
      type: "IP Address",
      value: "192.168.1.100",
      description: "Command & Control Server",
      confidence: "High",
      firstSeen: "2024-03-15",
      lastSeen: "2024-03-16",
      tags: ["Ransomware", "OT"]
    },
    // Add more IOCs
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Indicators of Compromise</h2>
      
      <div className="bg-slate-800 rounded-lg p-6">
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search IOCs..."
              className="w-full pl-10 pr-4 py-2 bg-slate-700 rounded-lg text-white placeholder-gray-400"
            />
          </div>
          <select className="px-4 py-2 bg-slate-700 rounded-lg text-white">
            <option value="all">All Types</option>
            <option value="ip">IP Addresses</option>
            <option value="domain">Domains</option>
            <option value="hash">File Hashes</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-slate-700">
                <th className="pb-3 text-gray-400 font-medium">Type</th>
                <th className="pb-3 text-gray-400 font-medium">Value</th>
                <th className="pb-3 text-gray-400 font-medium">Description</th>
                <th className="pb-3 text-gray-400 font-medium">Confidence</th>
                <th className="pb-3 text-gray-400 font-medium">First Seen</th>
                <th className="pb-3 text-gray-400 font-medium">Last Seen</th>
                <th className="pb-3 text-gray-400 font-medium">Tags</th>
              </tr>
            </thead>
            <tbody>
              {iocs.map((ioc) => (
                <tr key={ioc.id} className="border-b border-slate-700">
                  <td className="py-4 text-white">{ioc.type}</td>
                  <td className="py-4 text-cyan-500">{ioc.value}</td>
                  <td className="py-4 text-gray-300">{ioc.description}</td>
                  <td className="py-4">
                    <span className="px-2 py-1 rounded-full text-sm bg-green-500/10 text-green-500">
                      {ioc.confidence}
                    </span>
                  </td>
                  <td className="py-4 text-gray-300">{ioc.firstSeen}</td>
                  <td className="py-4 text-gray-300">{ioc.lastSeen}</td>
                  <td className="py-4">
                    <div className="flex gap-2">
                      {ioc.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="px-2 py-1 rounded-full text-sm bg-slate-700 text-gray-300"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}