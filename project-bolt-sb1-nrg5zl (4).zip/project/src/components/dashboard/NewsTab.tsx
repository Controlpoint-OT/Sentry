import React from 'react';
import { ExternalLink, AlertTriangle } from 'lucide-react';

interface NewsItem {
  id: number;
  title: string;
  description: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  date: string;
  source: string;
  sourceUrl: string;
  mitigation: string[];
}

const newsData: NewsItem[] = [
  {
    id: 1,
    title: "Critical Vulnerability in Siemens S7-1500 PLCs",
    description: "A critical vulnerability has been discovered in Siemens S7-1500 PLCs that could allow remote code execution.",
    severity: "Critical",
    date: "2024-03-15",
    source: "ICS-CERT",
    sourceUrl: "https://www.cisa.gov/news-events/cybersecurity-advisories",
    mitigation: [
      "Update firmware to latest version",
      "Implement network segmentation",
      "Monitor network traffic for suspicious activities"
    ]
  },
  // Add more news items here
];

export function NewsTab() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white mb-6">Latest OT Vulnerabilities</h2>
      
      {newsData.map((item) => (
        <div key={item.id} className="bg-slate-800 rounded-lg p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className={`h-6 w-6 ${
                item.severity === 'Critical' ? 'text-red-500' :
                item.severity === 'High' ? 'text-orange-500' :
                item.severity === 'Medium' ? 'text-yellow-500' :
                'text-green-500'
              }`} />
              <div>
                <h3 className="text-xl font-semibold text-white">{item.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm text-gray-400">{item.source}</span>
                  <a 
                    href={item.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-500 hover:text-cyan-400 inline-flex items-center gap-1"
                  >
                    <ExternalLink className="h-3 w-3" />
                    <span className="text-sm">View Source</span>
                  </a>
                  <span className="text-sm text-gray-400">| {item.date}</span>
                </div>
              </div>
            </div>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              item.severity === 'Critical' ? 'bg-red-500/10 text-red-500' :
              item.severity === 'High' ? 'bg-orange-500/10 text-orange-500' :
              item.severity === 'Medium' ? 'bg-yellow-500/10 text-yellow-500' :
              'bg-green-500/10 text-green-500'
            }`}>
              {item.severity}
            </span>
          </div>
          
          <p className="text-gray-300 mb-4">{item.description}</p>
          
          <div className="bg-slate-700/50 rounded-lg p-4">
            <h4 className="text-white font-semibold mb-2">Recommended Mitigation Steps:</h4>
            <ul className="list-disc list-inside space-y-1">
              {item.mitigation.map((step, index) => (
                <li key={index} className="text-gray-300">{step}</li>
              ))}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
}