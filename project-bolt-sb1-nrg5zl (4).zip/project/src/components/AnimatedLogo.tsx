import React from 'react';
import { Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

interface AnimatedLogoProps {
  className?: string;
  showText?: boolean;
}

export function AnimatedLogo({ className = '', showText = true }: AnimatedLogoProps) {
  return (
    <Link to="/" className={`flex items-center space-x-2 group ${className}`}>
      <div className="relative w-8 h-8">
        <Shield className="absolute inset-0 h-8 w-8 text-cyan-500 animate-pulse" />
        {/* Circuit Pattern Animation */}
        <div className="absolute inset-0">
          <svg
            className="w-full h-full"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              className="animate-pulse"
              d="M12 3L4 7.5V16.5L12 21L20 16.5V7.5L12 3Z"
              stroke="currentColor"
              strokeWidth="0.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              className="animate-dash"
              d="M12 3V21M4 7.5L20 16.5M20 7.5L4 16.5"
              stroke="currentColor"
              strokeWidth="0.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <style>
              {`
                @keyframes dash {
                  to {
                    stroke-dashoffset: 0;
                  }
                }
                .animate-dash {
                  stroke-dasharray: 30;
                  stroke-dashoffset: 30;
                  animation: dash 2s linear infinite;
                }
              `}
            </style>
          </svg>
        </div>
        {/* Glowing Effect */}
        <div className="absolute inset-0 rounded-full">
          <div className="absolute inset-0 bg-cyan-500 rounded-full blur-md opacity-30 animate-pulse"></div>
        </div>
      </div>
      {showText && (
        <span className="text-2xl font-bold text-white group-hover:text-cyan-500 transition-colors duration-300">
          Sentry
        </span>
      )}
    </Link>
  );
}