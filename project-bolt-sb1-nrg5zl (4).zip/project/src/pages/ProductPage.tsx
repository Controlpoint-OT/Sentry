import React, { useState, useEffect } from 'react';
import { DemoRequestModal } from '../components/DemoRequestModal';
import { Shield, AlertTriangle, Activity, Lock, Server, Network, Cpu, Zap, ArrowRight } from 'lucide-react';

export function ProductPage() {
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const highlights = [
    {
      icon: Server,
      title: "Industrial Control Systems",
      description: "Real-time monitoring and threat detection for ICS environments"
    },
    {
      icon: Network,
      title: "SCADA Networks",
      description: "Comprehensive security for supervisory control and data acquisition systems"
    },
    {
      icon: Cpu,
      title: "AI-Driven Analysis",
      description: "Advanced threat detection powered by artificial intelligence"
    },
    {
      icon: Zap,
      title: "Proactive Defense",
      description: "Stay ahead of threats with predictive security measures"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % highlights.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-slate-900 pt-24">
      {/* Hero Section with Gradient */}
      <div className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-cyan-900 mb-16">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxIDAgNiAyLjY5IDYgNnMtMi42OSA2LTYgNi02LTIuNjktNi02IDIuNjktNiA2LTZ6TTQgNGg1MnY1Mkg0VjR6IiBzdHJva2U9IiM2NEZCRDkiIHN0cm9rZS1vcGFjaXR5PSIuMSIvPjwvZz48L3N2Zz4=')] opacity-10"></div>
        <div className="container mx-auto px-4 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Text Content */}
            <div className="space-y-8">
              <div className="inline-block">
                <div className="flex items-center space-x-2 bg-cyan-500/10 rounded-full px-4 py-1">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-500 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
                  </span>
                  <span className="text-cyan-500 text-sm font-medium">Active Threat Protection</span>
                </div>
              </div>
              <h1 className="text-5xl font-bold text-white leading-tight">
                OT Threat Intelligence with{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-blue-500">
                  Sentry
                </span>
              </h1>
              <p className="text-xl text-gray-300 leading-relaxed">
                Purpose-built to provide real-time insights and proactive defense against evolving threats targeting OT environments, from industrial control systems to SCADA networks.
              </p>
              <div className="flex items-center space-x-6">
                <button
                  onClick={() => setShowDemoModal(true)}
                  className="px-8 py-4 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg transition-all transform hover:scale-105 flex items-center space-x-2 font-semibold"
                >
                  <span>Get Started</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
                <a href="#features" className="text-gray-400 hover:text-white transition-colors flex items-center space-x-2">
                  <span>Learn more</span>
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </div>

            {/* Right Column - Interactive Display */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg blur-3xl opacity-20 animate-pulse"></div>
              <div className="relative bg-slate-800 rounded-lg p-8 backdrop-blur-sm border border-slate-700">
                {highlights.map((item, index) => (
                  <div
                    key={index}
                    className={`transition-all duration-500 transform ${
                      index === activeIndex 
                        ? 'opacity-100 translate-x-0' 
                        : 'opacity-0 absolute inset-0 translate-x-8'
                    }`}
                  >
                    <div className="flex items-center space-x-6">
                      <div className="flex-shrink-0 bg-slate-700 p-4 rounded-lg">
                        <item.icon className="h-12 w-12 text-cyan-500" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-semibold text-white mb-2">{item.title}</h3>
                        <p className="text-gray-400 leading-relaxed">{item.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="flex justify-center mt-8 space-x-2">
                  {highlights.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setActiveIndex(index)}
                      className={`w-2 h-2 rounded-full transition-all duration-300 ${
                        index === activeIndex ? 'bg-cyan-500 w-8' : 'bg-slate-600'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Key Features Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">
            Advanced OT Threat Detection
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-slate-800 p-6 rounded-lg">
              <Shield className="h-12 w-12 text-cyan-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Proactive Monitoring</h3>
              <p className="text-gray-400">
                Continuously monitor and analyze OT-specific threats from multiple sources
              </p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg">
              <AlertTriangle className="h-12 w-12 text-cyan-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Early Warning System</h3>
              <p className="text-gray-400">
                Receive immediate alerts about potential threats to your OT infrastructure
              </p>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg">
              <Activity className="h-12 w-12 text-cyan-500 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Real-time Analytics</h3>
              <p className="text-gray-400">
                Advanced analytics and reporting for comprehensive threat assessment
              </p>
            </div>
          </div>
        </div>
      </section>

      <DemoRequestModal isOpen={showDemoModal} onClose={() => setShowDemoModal(false)} />
    </div>
  );
}