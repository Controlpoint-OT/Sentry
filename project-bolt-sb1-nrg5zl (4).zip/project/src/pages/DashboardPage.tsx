import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Navigate } from 'react-router-dom';
import { 
  Shield, Bell, AlertTriangle, Activity, 
  LayoutDashboard, Newspaper, Radio, Target, 
  Users, Bug, Building2, HeadphonesIcon,
  Settings, BellRing
} from 'lucide-react';
import { ThreatDatabase } from '../components/ThreatDatabase';
import { DashboardCharts } from '../components/dashboard/DashboardCharts';
import { NewsTab } from '../components/dashboard/NewsTab';
import { ThreatFeedsTab } from '../components/dashboard/ThreatFeedsTab';
import { IOCsTab } from '../components/dashboard/IOCsTab';

export function DashboardPage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = React.useState('dashboard');
  const [isHovered, setIsHovered] = React.useState<string | null>(null);

  if (!user) {
    return <Navigate to="/" replace />;
  }

  const sidebarItems = [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: LayoutDashboard,
      description: 'Overview of threats and analytics'
    },
    { 
      id: 'news', 
      label: 'News', 
      icon: Newspaper,
      description: 'Latest OT security news and updates'
    },
    { 
      id: 'threatFeeds', 
      label: 'Threat Feeds', 
      icon: Radio,
      description: 'Real-time threat intelligence feeds'
    },
    { 
      id: 'iocs', 
      label: 'IOCs', 
      icon: Target,
      description: 'Indicators of Compromise'
    },
    { 
      id: 'threatActor', 
      label: 'Threat Actor', 
      icon: Users,
      description: 'Known threat actors and groups'
    },
    { 
      id: 'aptFeeds', 
      label: 'APT Feeds', 
      icon: Bug,
      description: 'Advanced Persistent Threat feeds'
    },
    { 
      id: 'otVulnerabilities', 
      label: 'OT Vulnerabilities', 
      icon: Shield,
      description: 'OT-specific vulnerability database'
    },
    { 
      id: 'notifications', 
      label: 'Notifications', 
      icon: BellRing,
      description: 'System and threat notifications'
    },
    { 
      id: 'alertSettings', 
      label: 'Alert Settings', 
      icon: Bell,
      description: 'Configure alert preferences'
    },
    { 
      id: 'organization', 
      label: 'Organization', 
      icon: Building2,
      description: 'Organization settings and users'
    },
    { 
      id: 'support', 
      label: 'Support', 
      icon: HeadphonesIcon,
      description: '24/7 technical support'
    }
  ];

  const stats = {
    totalThreats: 3847,
    activeThreats: 256,
    criticalAlerts: 43,
    highSeverity: 189
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <>
            <DashboardCharts />
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Recent Threats</h2>
              <ThreatDatabase initialSearch="" />
            </div>
          </>
        );
      case 'news':
        return <NewsTab />;
      case 'threatFeeds':
        return <ThreatFeedsTab />;
      case 'iocs':
        return <IOCsTab />;
      default:
        return (
          <div className="flex items-center justify-center h-[400px] bg-slate-800 rounded-lg">
            <p className="text-gray-400">Content for {activeTab} tab is under development</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex">
      {/* Sidebar */}
      <div className="w-72 bg-slate-800 fixed h-screen pt-20 border-r border-slate-700">
        {/* User Info */}
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center space-x-3 mb-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg">
              <span className="text-white text-lg font-semibold">
                {user.name.charAt(0).toUpperCase()}
              </span>
            </div>
            <div>
              <h3 className="text-white font-semibold">{user.name}</h3>
              <p className="text-gray-400 text-sm">{user.company}</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="mt-4 px-2">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              onMouseEnter={() => setIsHovered(item.id)}
              onMouseLeave={() => setIsHovered(null)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 relative group mb-1
                ${activeTab === item.id
                  ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-500'
                  : 'text-gray-400 hover:bg-slate-700/50 hover:text-white'
                }
                ${isHovered === item.id ? 'shadow-lg scale-[1.02]' : ''}
              `}
            >
              <item.icon className={`h-5 w-5 transition-transform duration-200 ${
                isHovered === item.id ? 'scale-110' : ''
              }`} />
              <span className="flex-1 text-left">{item.label}</span>
              
              {/* Tooltip */}
              {isHovered === item.id && (
                <div className="absolute left-full ml-2 px-3 py-1 bg-slate-700 text-white text-sm rounded-md whitespace-nowrap z-50">
                  {item.description}
                </div>
              )}

              {/* Active Indicator */}
              {activeTab === item.id && (
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-gradient-to-b from-cyan-500 to-blue-500 rounded-l-full" />
              )}
            </button>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 ml-72 pt-20">
        <div className="p-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-slate-800 p-6 rounded-lg hover:bg-slate-700/80 transition-colors group">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                  <Shield className="h-8 w-8 text-cyan-500" />
                </div>
                <div>
                  <p className="text-gray-400">Total Threats</p>
                  <p className="text-2xl font-bold text-white">{stats.totalThreats.toLocaleString()}</p>
                </div>
              </div>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg hover:bg-slate-700/80 transition-colors group">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-yellow-500/10 rounded-lg group-hover:bg-yellow-500/20 transition-colors">
                  <Activity className="h-8 w-8 text-yellow-500" />
                </div>
                <div>
                  <p className="text-gray-400">Active Threats</p>
                  <p className="text-2xl font-bold text-white">{stats.activeThreats.toLocaleString()}</p>
                </div>
              </div>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg hover:bg-slate-700/80 transition-colors group">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-red-500/10 rounded-lg group-hover:bg-red-500/20 transition-colors">
                  <AlertTriangle className="h-8 w-8 text-red-500" />
                </div>
                <div>
                  <p className="text-gray-400">Critical Alerts</p>
                  <p className="text-2xl font-bold text-white">{stats.criticalAlerts.toLocaleString()}</p>
                </div>
              </div>
            </div>
            <div className="bg-slate-800 p-6 rounded-lg hover:bg-slate-700/80 transition-colors group">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-orange-500/10 rounded-lg group-hover:bg-orange-500/20 transition-colors">
                  <Bell className="h-8 w-8 text-orange-500" />
                </div>
                <div>
                  <p className="text-gray-400">High Severity</p>
                  <p className="text-2xl font-bold text-white">{stats.highSeverity.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Content */}
          <div className="transition-all duration-300 ease-in-out">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}