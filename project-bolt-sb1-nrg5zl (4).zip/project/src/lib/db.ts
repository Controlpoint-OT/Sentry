import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface User {
  id?: number;
  email: string;
  name: string;
  company: string;
  password: string;
  createdAt: Date;
  lastLogin?: Date;
}

interface SentryDB extends DBSchema {
  users: {
    key: number;
    value: User;
    indexes: {
      'by-email': string;
    };
  };
}

class UserDatabase {
  private db: Promise<IDBPDatabase<SentryDB>>;

  constructor() {
    this.db = this.initDB();
  }

  private async initDB() {
    return openDB<SentryDB>('sentry-db', 1, {
      upgrade(db) {
        const userStore = db.createObjectStore('users', {
          keyPath: 'id',
          autoIncrement: true,
        });
        userStore.createIndex('by-email', 'email', { unique: true });
      },
    });
  }

  async createUser(userData: Omit<User, 'id' | 'createdAt'>): Promise<User> {
    const db = await this.db;
    
    // Check if user already exists
    const existingUser = await this.getUserByEmail(userData.email);
    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    const user: Omit<User, 'id'> = {
      ...userData,
      createdAt: new Date(),
    };

    const id = await db.add('users', user);
    return { ...user, id };
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const db = await this.db;
    return db.getFromIndex('users', 'by-email', email);
  }

  async updateLastLogin(userId: number): Promise<void> {
    const db = await this.db;
    const user = await db.get('users', userId);
    if (user) {
      user.lastLogin = new Date();
      await db.put('users', user);
    }
  }

  async validateCredentials(email: string, password: string): Promise<User | null> {
    const user = await this.getUserByEmail(email);
    if (user && user.password === password) { // In production, use proper password hashing
      await this.updateLastLogin(user.id!);
      return user;
    }
    return null;
  }
}

export const userDB = new UserDatabase();